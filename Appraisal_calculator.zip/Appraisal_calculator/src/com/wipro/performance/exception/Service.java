package com.wipro.performance.exception;

import java.sql.Date;
import java.text.SimpleDateFormat;

import com.wipro.performance.bean.EmployeeBean;
import com.wipro.performance.entity.InvalidADIDException;
import com.wipro.performance.entity.InvalidBUException;
import com.wipro.performance.entity.InvalidCurrentSalaryException;
import com.wipro.performance.entity.InvalidDOJException;

public class Service {
	public String validateData(EmployeeBean ebean) throws InvalidBUException, InvalidDOJException, InvalidCurrentSalaryException
	{
		
			int t=0;
				for(int i=0;i<ebean.getADID().length();i++)
				{
						if(!(Character.isLetterOrDigit(ebean.getADID().charAt(i))&&ebean.getADID().length()==6))
								t=1;
				}
				if(t!=0)
						try {
							throw new InvalidADIDException();
							}catch (InvalidADIDException e) {
									return e.toString();
									// TODO Auto-generated catch block
									//e.printStackTrace();
							}
				if(!(ebean.getBusinessUnit().equalsIgnoreCase("JAVA")||ebean.getBusinessUnit().equalsIgnoreCase("Oracle")||ebean.getBusinessUnit().equalsIgnoreCase("BigData")))
						try{
							throw new InvalidBUException();
							}catch(InvalidBUException e){
									return e.toString();
							}
		Date cdate = new Date(System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat( "dd/MM/YYYY" );
				if(!(ebean.getDateOfJoining().before(cdate))||sdf.format(cdate).equals(sdf.format(ebean.getDateOfJoining())))
						try{
							throw new InvalidDOJException();
							}catch(InvalidDOJException e)	{
									return e.toString();
							}
				if(ebean.getCurrentSalary()<50000)
						try{
							throw new InvalidCurrentSalaryException();
							}catch(InvalidCurrentSalaryException e)	{
									return e.toString();
							}
				if(!(ebean.getTotalAttendance()>=0&&ebean.getTotalAttendance()<=200))
					return"Invalid Attendance";
				if(!(ebean.getManagerRating()>=0&&ebean.getManagerRating()<=5))
					return "Invalid Rating";
				return "SUCCESS";
		
		
	}
	public String computeAppraisal(EmployeeBean ebean) throws InvalidADIDException, InvalidBUException, InvalidDOJException, InvalidCurrentSalaryException {
		float hike=0;
		if(validateData(ebean).equals("SUCCESS"))
		{
			if(ebean.getTotalAttendance()<=100)
				hike+=0;
			else if(ebean.getTotalAttendance()>100&&ebean.getTotalAttendance()<=150)
				hike+=(float) (0.05*ebean.getCurrentSalary());
			else if(ebean.getTotalAttendance()<=200)
				hike+=(float) (0.06*ebean.getCurrentSalary());
			if(ebean.getManagerRating()==5)
				hike+=(float) (0.1*ebean.getCurrentSalary());
			else if(ebean.getManagerRating()==4)
				hike+=(float) (0.09*ebean.getCurrentSalary());
			else if(ebean.getManagerRating()==3)
				hike+=(float) (0.08*ebean.getCurrentSalary());
			else if(ebean.getManagerRating()==2)
				hike+=(float) (0.07*ebean.getCurrentSalary());
			else if(ebean.getManagerRating()==1)
				hike+=(float) (0.06*ebean.getCurrentSalary());
			else if(ebean.getManagerRating()==0)
				hike+=0;
			return ""+(ebean.getCurrentSalary()+hike);
		}
		else
		return validateData(ebean);
	}
	public String getAppraisalDetails(EmployeeBean ebean) throws InvalidADIDException, InvalidBUException, InvalidDOJException, InvalidCurrentSalaryException
	{
		String newSalaryinfo=computeAppraisal(ebean);
		try {
		Float.parseFloat(newSalaryinfo);
		ebean.setCurrentSalary(Float.parseFloat(newSalaryinfo));
		return ebean.getADID()+":"+ebean.getCurrentSalary();
		}
		catch (NumberFormatException e){
		return ebean.getADID()+":"+newSalaryinfo;
		}
	}
}
