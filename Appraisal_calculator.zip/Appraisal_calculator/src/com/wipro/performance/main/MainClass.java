package com.wipro.performance.main;

import java.util.Date;
import java.util.Scanner;

import com.wipro.performance.bean.EmployeeBean;
import com.wipro.performance.entity.InvalidADIDException;
import com.wipro.performance.entity.InvalidBUException;
import com.wipro.performance.entity.InvalidCurrentSalaryException;
import com.wipro.performance.entity.InvalidDOJException;
import com.wipro.performance.exception.Service;

public class MainClass {
	public static void main(String args[]) throws InvalidADIDException, InvalidBUException, InvalidDOJException, InvalidCurrentSalaryException{
		
		EmployeeBean ebean=new EmployeeBean();
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter ADID");
		ebean.setADID(sc.next());
		System.out.println("Enter Name of the employee");
		ebean.setEmpName(sc.next());
		System.out.println("Enter Business Unit");
		ebean.setBusinessUnit(sc.next());
		System.out.println("Enter joining date");
		Date d=new Date(sc1.nextLine());
		ebean.setDateOfJoining(d);
		System.out.println("Enter the current salary");
		ebean.setCurrentSalary(sc.nextFloat());
		System.out.println("Enter total attendance");
		ebean.setTotalAttendance(sc.nextInt());
		System.out.println("Enter manager rating");
		ebean.setManagerRating(sc.nextInt());
		Service s=new Service();
		System.out.println("Appraisal Details");
		System.out.println(s.getAppraisalDetails(ebean));
		 
}
}