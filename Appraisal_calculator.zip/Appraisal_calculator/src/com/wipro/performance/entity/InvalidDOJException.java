package com.wipro.performance.entity;

public class InvalidDOJException extends Exception{
	public String toString() {
		
		return "Invalid Date Of Joining";
	}
}
