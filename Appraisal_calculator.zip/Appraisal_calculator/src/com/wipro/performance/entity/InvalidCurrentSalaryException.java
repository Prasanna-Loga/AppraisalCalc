package com.wipro.performance.entity;

public class InvalidCurrentSalaryException extends Exception{
	public String toString() {
		
		return "Invalid Current Salary";
	}
}
