package com.wipro.performance.entity;

public class InvalidADIDException extends Exception{
	public String toString() {
		
		return "Invalid ADID";
	}
}
